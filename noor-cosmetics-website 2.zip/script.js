const products=[
{name:"BIOAQUA Cucumber Mask",price:500},
{name:"Revolution Glow Highlighter",price:700},
{name:"SHEGLAM Beauty Book Makeup Kit",price:3500}
];
let cart=0;
const box=document.getElementById("products");
function render(list=products){box.innerHTML=list.map((p,i)=>`<article class="card"><div class="pic">NOOR<br>BEAUTY</div><h3>${p.name}</h3><p class="price">Rs. ${p.price.toLocaleString()}</p><button onclick="add()">Add to Cart</button></article>`).join("")}
function add(){cart++;document.getElementById("count").textContent=cart;alert("Added to cart");}
function showCart(){alert(`Your cart has ${cart} item(s).`)}
document.getElementById("search").addEventListener("input",e=>{let q=e.target.value.toLowerCase();render(products.filter(p=>p.name.toLowerCase().includes(q)))});
render();
